defmodule Todolist.Mailer do
  use Swoosh.Mailer, otp_app: :api
end
