[
  inputs: ["{mix,.formatter}.exs", "{lib,test}/**/*.{ex,exs}"]
]
